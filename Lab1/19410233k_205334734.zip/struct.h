#ifndef struct_h_
#define struct_h_

typedef struct {
  int posicion; //posicion donde caera la particula
  double energia; //energia de la particula
}Particula;


#endif // struct_h_